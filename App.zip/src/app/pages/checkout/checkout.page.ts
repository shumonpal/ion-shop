import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { CartService } from 'src/app/providers/cart.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.page.html',
  styleUrls: ['./checkout.page.scss'],
})
export class CheckoutPage implements OnInit {
  carts: any = [];
  product:object = {};
  totalPrice:number;
  grandTotal:number;

  checkoutForm:FormGroup;

  constructor(
    private cartSrvc:CartService,
    private navC:NavController,
  ) {
    this.cartSrvc.getAll().then((items) => {
      this.carts = items;
      var total = 0;
      items.forEach((item) => {
        total += Number(item.price * item.qty);
      });
      this.totalPrice = total;
      this.grandTotal = total;
    });
    this.createCheckoutForm();
   }

  ngOnInit() {
  }

  createCheckoutForm(){
    this.checkoutForm = new FormGroup({
      shipping: new FormControl('', [Validators.required]),
      payment_opt: new FormControl('', [Validators.required])
    });
    this.checkoutForm.valueChanges.subscribe((res)=> {
      // console.log("this.checkoutForm", this.checkoutForm.controls.shipping.value);      
      this.grandTotal = this.totalPrice + Number(this.checkoutForm.controls.shipping.value);    
    });    
  }

  checkoutSubmit(){
    if (this.checkoutForm.controls.payment_opt.value == "paypal") {
      console.log("payment_opt", this.checkoutForm.controls.payment_opt.value)
    } else if(this.checkoutForm.controls.payment_opt.value == "master") {
      console.log("payment_opt", this.checkoutForm.controls.payment_opt.value)      
    }
  }

  goBack(){
    this.navC.back();
  }

}
